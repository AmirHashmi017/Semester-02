﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Labwork.DL;
using Labwork.BL;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string name = textBox1.Text;
            float ecat = Convert.ToSingle(textBox2.Text);
            float fsc = Convert.ToSingle(textBox3.Text);
            float matric = Convert.ToSingle(textBox4.Text);
            int roll = Convert.ToInt32(textBox5.Text);

            Student student = new Student(roll, name, ecat, fsc, matric);
            
            Pref form = new Pref(student);
            form.Show();

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dt.Columns.Clear();
            dt.Rows.Clear();
            //int selectedRows;
            dt.Columns.Add("Roll", typeof(string));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Fsc", typeof(string));

            dataGridView1.DataSource = dt;

            List<Student> students = StudentDL.GetAllStudents();
            foreach (Student student in students)
            {
                dt.Rows.Add(student.Roll, student.Name, student.FSc);
            }
            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int roll = Convert.ToInt32(textBox5.Text);

            dt.Columns.Clear();
            dt.Rows.Clear();

            dt.Columns.Add("Roll", typeof(string));
            dt.Columns.Add("Title", typeof(string));
            dataGridView1.DataSource = dt;

            List<DegreeProgram> Prefs = StudentDL.LoadStudentAllPrefencesbyRoll(roll);
            foreach (DegreeProgram pref in Prefs)
            {
                dt.Rows.Add(roll, pref.Title);
            }
            dataGridView1.DataSource = dt;
        }
    }
}
